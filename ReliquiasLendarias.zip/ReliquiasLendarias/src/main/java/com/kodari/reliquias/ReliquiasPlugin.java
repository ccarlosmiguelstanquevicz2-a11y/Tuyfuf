package com.kodari.reliquias;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class ReliquiasPlugin extends JavaPlugin implements Listener {

    // Painel: relíquias em duas fileiras de 5, centralizadas.
    private static final int[] RELIC_SLOTS = {11, 12, 13, 14, 15, 29, 30, 31, 32, 33};
    private static final int SLOT_ALL = 47, SLOT_RANDOM = 49, SLOT_CLOSE = 51, SLOT_HEADER = 4;

    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();
    private NamespacedKey relicKey;
    private long orbitTick;
    private final Map<UUID, Relic> lastHeld = new HashMap<>();

    public static Component c(String s) {
        return LegacyComponentSerializer.legacySection().deserialize(s)
                .decoration(TextDecoration.ITALIC, false);
    }

    public static class PanelHolder implements InventoryHolder {
        private Inventory inv;
        @Override public Inventory getInventory() { return inv; }
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        relicKey = new NamespacedKey(this, "relic_id"); // mesma chave da versão antiga: itens antigos continuam funcionando
        Bukkit.getPluginManager().registerEvents(this, this);
        // a cada 2 ticks: partículas girando + passivas enquanto a relíquia estiver na mão
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            orbitTick++;
            for (Player pl : Bukkit.getOnlinePlayers()) {
                Relic held = getRelic(pl.getInventory().getItemInMainHand());
                Relic last = lastHeld.get(pl.getUniqueId());
                if (held != last) {
                    if (last != null) Abilities.removePassive(last, pl); // tirou da mão: tudo some
                    if (held == null) lastHeld.remove(pl.getUniqueId());
                    else lastHeld.put(pl.getUniqueId(), held);
                }
                if (held == null) continue;
                Abilities.orbit(held, pl, orbitTick);
                if (orbitTick % 10 == 0 || held != last) Abilities.passive(held, pl);
            }
        }, 2L, 2L);
        getLogger().info(Relic.values().length + " relíquias lendárias carregadas.");
    }

    // ---------- comando ----------
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Este comando só pode ser usado por um jogador.");
            return true;
        }
        if (!p.isOp() && !p.hasPermission("reliquias.painel")) {
            p.sendMessage(c("§cApenas operadores podem usar este comando."));
            return true;
        }
        openPanel(p);
        return true;
    }

    // ---------- itens ----------
    private ItemStack createRelic(Relic r) {
        ItemStack it = new ItemStack(r.material);
        ItemMeta m = it.getItemMeta();
        m.displayName(c(r.color + "§l" + r.displayName));
        m.lore(loreOf(r, false));
        m.setEnchantmentGlintOverride(true);
        m.setMaxStackSize(1);
        if (getConfig().getBoolean("usar-item-model", false)) {
            m.setItemModel(new NamespacedKey("reliquias", r.id));
        }
        m.getPersistentDataContainer().set(relicKey, PersistentDataType.STRING, r.id);
        it.setItemMeta(m);
        return it;
    }

    private List<Component> loreOf(Relic r, boolean panel) {
        String sep = "§8§m                                  ";
        List<Component> l = new ArrayList<>();
        l.add(c("§6✦ §e§lLENDÁRIA §6✦"));
        l.add(c("§7" + r.lore));
        l.add(c(sep));
        l.add(c("§b◈ Passiva §8» " + r.color + r.passiveName));
        l.add(c("  §7" + r.passiveDesc));
        l.add(c(" "));
        l.add(c("§a⚔ Habilidade §8» " + r.color + r.abilityName));
        l.add(c("  §8Botão direito §7• §b⏱ " + fmt(cooldownOf(r)) + "s"));
        l.add(c("  §7" + r.abilityDesc));
        l.add(c(" "));
        l.add(c("§d✪ Ultimate §8» " + r.color + r.ultName));
        l.add(c("  §8Agachado + botão direito §7• §b⏱ " + fmt(ultCooldownOf(r)) + "s"));
        l.add(c("  §7" + r.ultDesc));
        l.add(c(sep));
        if (panel) l.add(c("§e▶ §fClique para receber"));
        return l;
    }

    private static String fmt(double d) {
        return d == Math.floor(d) ? String.valueOf((long) d) : String.format(Locale.ROOT, "%.1f", d);
    }

    // ---------- proteções: não colocar nem largar no chão ----------
    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (getRelic(e.getItemInHand()) != null) e.setCancelled(true);
    }

    @EventHandler
    public void onEntityInteract(PlayerInteractEntityEvent e) {
        PlayerInventory inv = e.getPlayer().getInventory();
        ItemStack it = e.getHand() == EquipmentSlot.HAND ? inv.getItemInMainHand() : inv.getItemInOffHand();
        if (getRelic(it) != null) e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (getConfig().getBoolean("bloquear-drop", true) && getRelic(e.getItemDrop().getItemStack()) != null) {
            e.setCancelled(true);
        }
    }

    private double cooldownOf(Relic r) {
        return getConfig().getDouble("cooldowns." + r.id, r.cooldown);
    }

    private double ultCooldownOf(Relic r) {
        return getConfig().getDouble("ultimates." + r.id, r.ultCooldown);
    }

    private Relic getRelic(ItemStack it) {
        if (it == null || it.getType() == Material.AIR || !it.hasItemMeta()) return null;
        String id = it.getItemMeta().getPersistentDataContainer().get(relicKey, PersistentDataType.STRING);
        return id == null ? null : Relic.byId(id);
    }

    private void give(Player p, Relic r) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(createRelic(r));
        left.values().forEach(i -> p.getWorld().dropItemNaturally(p.getLocation(), i));
    }

    // ---------- painel ----------
    private ItemStack icon(Material mat, String name, String... lore) {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.displayName(c(name));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(c(s));
            m.lore(l);
        }
        m.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        it.setItemMeta(m);
        return it;
    }

    private Material paneFor(Relic r) {
        switch (r) {
            case DRAGON:  return Material.RED_STAINED_GLASS_PANE;
            case ECLIPSE: return Material.PURPLE_STAINED_GLASS_PANE;
            case PHOENIX: return Material.ORANGE_STAINED_GLASS_PANE;
            case TITAN:   return Material.GRAY_STAINED_GLASS_PANE;
            case STORM:   return Material.LIGHT_BLUE_STAINED_GLASS_PANE;
            case VOID:    return Material.MAGENTA_STAINED_GLASS_PANE;
            case BLOOD:   return Material.BROWN_STAINED_GLASS_PANE;
            case FROST:   return Material.CYAN_STAINED_GLASS_PANE;
            case THUNDER: return Material.YELLOW_STAINED_GLASS_PANE;
            default:      return Material.WHITE_STAINED_GLASS_PANE;
        }
    }

    // Moldura em ordem horária (para o brilho que corre pela borda)
    private static final int[] RING = {0, 1, 2, 3, 4, 5, 6, 7, 8, 17, 26, 35, 44, 53,
            52, 51, 50, 49, 48, 47, 46, 45, 36, 27, 18, 9};
    private static final Set<Integer> RING_SKIP = Set.of(1, 4, 7, 47, 49, 51);

    private void openPanel(Player p) {
        PanelHolder holder = new PanelHolder();
        Inventory inv = Bukkit.createInventory(holder, 54,
                c("§8§l« §6§l✦ §e§lARTEFATOS LENDÁRIOS §6§l✦ §8§l»"));
        holder.inv = inv;

        // fundo escuro para as cores se destacarem
        ItemStack black = icon(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) inv.setItem(i, black);

        // moldura com brilho animado (laranja → amarelo → branco)
        Material[] pal = {Material.ORANGE_STAINED_GLASS_PANE, Material.ORANGE_STAINED_GLASS_PANE,
                Material.YELLOW_STAINED_GLASS_PANE, Material.WHITE_STAINED_GLASS_PANE,
                Material.YELLOW_STAINED_GLASS_PANE, Material.ORANGE_STAINED_GLASS_PANE};
        ItemStack[] frames = new ItemStack[pal.length];
        for (int i = 0; i < pal.length; i++) frames[i] = icon(pal[i], "§6✦");
        for (int i = 0; i < RING.length; i++) {
            if (!RING_SKIP.contains(RING[i])) inv.setItem(RING[i], frames[i % frames.length]);
        }

        // cabeçalho e informações
        inv.setItem(4, icon(Material.ENCHANTED_BOOK, "§6§l✦ Artefatos Lendários ✦",
                "§7Escolha um artefato para receber.",
                "§7Cada um tem §e3 poderes §7únicos."));
        inv.setItem(1, icon(Material.COMPASS, "§e§lComo usar",
                "§b◈ Passiva §7- ativa ao segurar na mão",
                "§a⚔ Habilidade §7- botão direito",
                "§d✪ Ultimate §7- agachado + botão direito",
                "§8Tirou da mão, tudo para."));
        inv.setItem(7, icon(Material.KNOWLEDGE_BOOK, "§e§lInformações",
                "§7Artefatos: §f" + Relic.values().length,
                "§7Não podem ser colocados no chão."));

        // artefatos: item em cima + faixa colorida embaixo (também clicável)
        Relic[] all = Relic.values();
        for (int i = 0; i < all.length && i < RELIC_SLOTS.length; i++) {
            Relic r = all[i];
            ItemStack it = createRelic(r);
            ItemMeta m = it.getItemMeta();
            m.lore(loreOf(r, true));
            it.setItemMeta(m);
            inv.setItem(RELIC_SLOTS[i], it);
            inv.setItem(RELIC_SLOTS[i] + 9, icon(paneFor(r), r.color + "§l✦ " + r.displayName,
                    "§e▶ §fClique para receber"));
        }

        // botões
        inv.setItem(SLOT_ALL, icon(Material.BEACON, "§b§l✔ Receber todos",
                "§7Recebe os " + all.length + " artefatos de uma vez."));
        inv.setItem(SLOT_RANDOM, icon(Material.ENDER_EYE, "§d§l✧ Artefato aleatório",
                "§7Deixe o destino escolher por você."));
        inv.setItem(SLOT_CLOSE, icon(Material.BARRIER, "§c§l✖ Fechar"));

        new BukkitRunnable() {
            int phase = 0;
            @Override public void run() {
                if (inv.getViewers().isEmpty()) { cancel(); return; }
                phase++;
                for (int i = 0; i < RING.length; i++) {
                    if (!RING_SKIP.contains(RING[i])) inv.setItem(RING[i], frames[(i + phase) % frames.length]);
                }
            }
        }.runTaskTimer(this, 2L, 3L);

        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 0.7f, 1.2f);
        p.playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.8f, 1.5f);
    }

    private boolean isPanel(Inventory top) {
        return top != null && top.getHolder() instanceof PanelHolder;
    }

    @EventHandler
    public void onPanelClick(InventoryClickEvent e) {
        if (!isPanel(e.getView().getTopInventory())) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;

        int slot = e.getRawSlot();
        Relic[] all = Relic.values();
        for (int i = 0; i < all.length && i < RELIC_SLOTS.length; i++) {
            if (RELIC_SLOTS[i] == slot || RELIC_SLOTS[i] + 9 == slot) {
                give(p, all[i]);
                p.sendMessage(c("§aVocê recebeu: " + all[i].color + "§l" + all[i].displayName + "§a!"));
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.4f);
                return;
            }
        }
        if (slot == SLOT_ALL) {
            for (Relic r : all) give(p, r);
            p.sendMessage(c("§aVocê recebeu todos os artefatos lendários!"));
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        } else if (slot == SLOT_RANDOM) {
            Relic r = all[new Random().nextInt(all.length)];
            give(p, r);
            p.sendMessage(c("§dO destino escolheu: " + r.color + "§l" + r.displayName + "§d!"));
            p.playSound(p.getLocation(), Sound.ENTITY_ENDER_EYE_DEATH, 1f, 1.2f);
        } else if (slot == SLOT_CLOSE) {
            p.closeInventory();
        }
    }

    @EventHandler
    public void onPanelDrag(InventoryDragEvent e) {
        if (isPanel(e.getView().getTopInventory())) e.setCancelled(true);
    }

    // ---------- uso (somente botão direito) ----------
    @EventHandler
    public void onRelicUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        Relic r = getRelic(p.getInventory().getItemInMainHand());
        if (r == null) return;
        e.setCancelled(true); // evita arremessar o tridente, descascar troncos, etc.

        boolean ult = p.isSneaking();
        String key = ult ? r.id + "_ult" : r.id;
        String name = ult ? r.ultName : r.abilityName;
        long now = System.currentTimeMillis();
        Map<String, Long> map = cooldowns.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>());
        long until = map.getOrDefault(key, 0L);
        if (now < until) {
            p.sendActionBar(c("§c" + name + " em recarga: §f"
                    + String.format(Locale.ROOT, "%.1f", (until - now) / 1000.0) + "s"));
            return;
        }
        boolean ok = ult ? Abilities.ultimate(r, p) : Abilities.cast(r, p);
        if (!ok) return;
        map.put(key, now + (long) ((ult ? ultCooldownOf(r) : cooldownOf(r)) * 1000));
        p.sendActionBar(c(r.color + "§l" + name + " §7ativada!"));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        cooldowns.remove(e.getPlayer().getUniqueId());
        lastHeld.remove(e.getPlayer().getUniqueId());
    }
}
