package com.kodari.reliquias;

import org.bukkit.Material;

public enum Relic {
    DRAGON("dragao", Material.DRAGON_BREATH, "Sopro do Dragão", "§c", 14,
            "Sopro Dracônico", "Cone de fogo que queima e fere inimigos à frente.",
            "Pele de Dragão", "Resistência ao fogo enquanto segura.",
            "Fúria Dracônica", "Anel de fogo gigante: 10 de dano e queima em 8 blocos.", 60,
            "Um sopro engarrafado do último dragão."),
    ECLIPSE("eclipse", Material.ECHO_SHARD, "Fragmento do Eclipse", "§5", 16,
            "Eclipse Total", "Cega e faz definhar os inimigos em 6 blocos.",
            "Visão Sombria", "Visão noturna enquanto segura.",
            "Escuridão Total", "Trevas em 10 blocos: cegueira, escuridão e Wither forte.", 60,
            "Um caco de pura escuridão."),
    PHOENIX("fenix", Material.BLAZE_ROD, "Cetro da Fênix", "§6", 18,
            "Renascer das Cinzas", "Cura 4 corações, dá regeneração e queima quem está perto.",
            "Chama Vital", "Regeneração lenta enquanto segura.",
            "Ressurreição", "Cura total, escudo extra e explosão de fogo em 6 blocos.", 70,
            "Carrega o calor da renovação."),
    TITAN("tita", Material.DIAMOND, "Diamante do Titã", "§7", 20,
            "Terremoto", "Pancada no chão: arremessa e retarda inimigos em 5 blocos.",
            "Pele de Pedra", "Resistência a dano enquanto segura.",
            "Queda do Titã", "Onda de impacto em 8 blocos: 12 de dano, arremesso e fraqueza.", 60,
            "Pesado o bastante para derrubar gigantes."),
    STORM("tempestade", Material.HEART_OF_THE_SEA, "Coração da Tempestade", "§b", 18,
            "Fúria da Tempestade", "Chama raios sobre os 3 inimigos mais próximos.",
            "Pulmões do Mar", "Respira na água e nada mais rápido.",
            "Tempestade Total", "Raios em até 6 inimigos num raio de 15 blocos.", 60,
            "A força dos oceanos pulsa dentro dele."),
    VOID("vazio", Material.ENDER_EYE, "Olho do Vazio", "§d", 10,
            "Passo do Vazio", "Teleporta 8 blocos à frente ferindo quem estiver no caminho.",
            "Passos Leves", "Velocidade e queda lenta enquanto segura.",
            "Fenda do Vazio", "Puxa inimigos em 10 blocos até você e os fere.", 50,
            "Enxerga além do mundo."),
    BLOOD("sangue", Material.GHAST_TEAR, "Lágrima Sanguínea", "§4", 12,
            "Sede de Sangue", "Drena a vida do inimigo mais próximo e te dá força.",
            "Sangue Quente", "Força enquanto segura.",
            "Banho de Sangue", "Fere todos em 7 blocos e recupera vida por cada um.", 55,
            "Uma gota antiga, sedenta por batalhas."),
    FROST("geada", Material.PRISMARINE_CRYSTALS, "Cristal da Geada", "§3", 15,
            "Nevasca", "Congela inimigos em 6 blocos com lentidão forte.",
            "Coração Gelado", "Pressa nas mãos e imunidade ao congelamento.",
            "Era Glacial", "Gelo em 9 blocos: dano, lentidão extrema e cegueira breve.", 60,
            "Fria como o inverno."),
    THUNDER("trovao", Material.AMETHYST_SHARD, "Estilhaço do Trovão", "§e", 16,
            "Julgamento do Trovão", "Raio no ponto mirado (até 20 blocos) com dano em área.",
            "Pés Elétricos", "Super pulo enquanto segura.",
            "Tormenta", "5 raios na área mirada com dano pesado.", 60,
            "Um cristal que ecoa como um raio."),
    STAR("estrela", Material.NETHER_STAR, "Estrela Ancestral", "§f", 20,
            "Chuva Estelar", "Revela inimigos em 7 blocos e te dá velocidade e escudo.",
            "Sorte Estelar", "Vida extra (+1 coração) enquanto segura.",
            "Supernova", "Explosão estelar em 10 blocos: 12 de dano, brilho e arremesso.", 70,
            "Uma relíquia brilhante com poder surpreendente.");

    public final String id;
    public final Material material;
    public final String displayName;
    public final String color;
    public final double cooldown;
    public final String abilityName;
    public final String abilityDesc;
    public final String passiveName;
    public final String passiveDesc;
    public final String ultName;
    public final String ultDesc;
    public final double ultCooldown;
    public final String lore;

    Relic(String id, Material material, String displayName, String color, double cooldown,
          String abilityName, String abilityDesc, String passiveName, String passiveDesc,
          String ultName, String ultDesc, double ultCooldown, String lore) {
        this.id = id;
        this.material = material;
        this.displayName = displayName;
        this.color = color;
        this.cooldown = cooldown;
        this.abilityName = abilityName;
        this.abilityDesc = abilityDesc;
        this.passiveName = passiveName;
        this.passiveDesc = passiveDesc;
        this.ultName = ultName;
        this.ultDesc = ultDesc;
        this.ultCooldown = ultCooldown;
        this.lore = lore;
    }

    public static Relic byId(String id) {
        for (Relic r : values()) if (r.id.equals(id)) return r;
        return null;
    }
}
