package com.kodari.reliquias;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.*;

/** Habilidades (botão direito) de cada relíquia. Retorna false se não pôde ser usada. */
public final class Abilities {
    private Abilities() {}

    public static boolean cast(Relic r, Player p) {
        switch (r) {
            case DRAGON:  return dragon(p);
            case ECLIPSE: return eclipse(p);
            case PHOENIX: return phoenix(p);
            case TITAN:   return titan(p);
            case STORM:   return storm(p);
            case VOID:    return voidStep(p);
            case BLOOD:   return blood(p);
            case FROST:   return frost(p);
            case THUNDER: return thunder(p);
            case STAR:    return star(p);
            default:      return false;
        }
    }

    // ---------- utilidades ----------
    static boolean isEnemy(Player p, LivingEntity le) {
        if (le.equals(p) || le instanceof ArmorStand || le.isDead() || !le.isValid()) return false;
        if (le instanceof Player o) {
            if (o.getGameMode() == GameMode.SPECTATOR || o.getGameMode() == GameMode.CREATIVE) return false;
            Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();
            Team a = sb.getEntryTeam(p.getName());
            Team b = sb.getEntryTeam(o.getName());
            if (a != null && a.equals(b)) return false;
        }
        return true;
    }

    static List<LivingEntity> enemies(Player p, Location center, double radius) {
        List<LivingEntity> out = new ArrayList<>();
        for (Entity en : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (en instanceof LivingEntity le && isEnemy(p, le)
                    && le.getLocation().distanceSquared(center) <= radius * radius) {
                out.add(le);
            }
        }
        return out;
    }

    static List<LivingEntity> enemies(Player p, double radius) {
        return enemies(p, p.getLocation(), radius);
    }

    static void ring(Location c, double radius, Particle particle, int points) {
        World w = c.getWorld();
        for (int i = 0; i < points; i++) {
            double a = 2 * Math.PI * i / points;
            w.spawnParticle(particle, c.getX() + Math.cos(a) * radius, c.getY() + 0.2,
                    c.getZ() + Math.sin(a) * radius, 1, 0, 0, 0, 0);
        }
    }

    static void heal(Player p, double amount) {
        AttributeInstance max = p.getAttribute(Attribute.MAX_HEALTH);
        double m = max == null ? 20.0 : max.getValue();
        p.setHealth(Math.min(m, p.getHealth() + amount));
    }

    static void fx(LivingEntity e, PotionEffectType t, int ticks, int amp) {
        e.addPotionEffect(new PotionEffect(t, ticks, amp));
    }

    // ---------- habilidades ----------
    private static boolean dragon(Player p) {
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        World w = p.getWorld();
        for (double t = 1; t <= 7; t += 0.5) {
            Location l = eye.clone().add(dir.clone().multiply(t));
            w.spawnParticle(Particle.FLAME, l, 8, 0.3 + t * 0.05, 0.3 + t * 0.05, 0.3 + t * 0.05, 0.02);
        }
        for (LivingEntity le : enemies(p, 7)) {
            Vector to = le.getLocation().add(0, le.getHeight() / 2, 0).toVector().subtract(eye.toVector());
            if (to.lengthSquared() == 0) continue;
            if (to.normalize().dot(dir) > 0.55) {
                le.setFireTicks(100);
                le.damage(6, p);
            }
        }
        w.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_SHOOT, 1f, 0.9f);
        return true;
    }

    private static boolean eclipse(Player p) {
        Location c = p.getLocation();
        ring(c, 6, Particle.SMOKE, 60);
        ring(c, 3, Particle.SMOKE, 30);
        for (LivingEntity le : enemies(p, 6)) {
            fx(le, PotionEffectType.BLINDNESS, 80, 0);
            fx(le, PotionEffectType.WITHER, 60, 0);
            le.damage(4, p);
        }
        p.getWorld().playSound(c, Sound.ENTITY_WITHER_AMBIENT, 1f, 0.6f);
        return true;
    }

    private static boolean phoenix(Player p) {
        Location c = p.getLocation();
        heal(p, 8);
        fx(p, PotionEffectType.REGENERATION, 100, 1);
        ring(c, 4, Particle.FLAME, 50);
        p.getWorld().spawnParticle(Particle.HEART, c.clone().add(0, 1.8, 0), 6, 0.4, 0.3, 0.4, 0);
        for (LivingEntity le : enemies(p, 4)) {
            le.setFireTicks(80);
            le.damage(5, p);
            Vector kb = le.getLocation().toVector().subtract(c.toVector()).setY(0.35);
            if (kb.lengthSquared() > 0) le.setVelocity(kb.normalize().multiply(0.6).setY(0.35));
        }
        p.getWorld().playSound(c, Sound.ENTITY_BLAZE_SHOOT, 1f, 0.8f);
        return true;
    }

    private static boolean titan(Player p) {
        Location c = p.getLocation();
        World w = c.getWorld();
        ring(c, 5, Particle.EXPLOSION, 20);
        ring(c, 3, Particle.CRIT, 40);
        fx(p, PotionEffectType.RESISTANCE, 100, 0);
        for (LivingEntity le : enemies(p, 5)) {
            le.damage(8, p);
            le.setVelocity(new Vector(0, 0.9, 0));
            fx(le, PotionEffectType.SLOWNESS, 60, 1);
        }
        w.playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 0.6f);
        w.playSound(c, Sound.BLOCK_ANVIL_LAND, 1f, 0.5f);
        return true;
    }

    private static boolean storm(Player p) {
        List<LivingEntity> list = enemies(p, 12);
        if (list.isEmpty()) { fail(p, "Nenhum inimigo por perto. Alcance: 12 blocos."); return false; }
        list.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(p.getLocation())));
        int n = Math.min(3, list.size());
        for (int i = 0; i < n; i++) {
            LivingEntity le = list.get(i);
            le.getWorld().strikeLightningEffect(le.getLocation());
            le.damage(7, p);
            fx(le, PotionEffectType.SLOWNESS, 40, 0);
        }
        return true;
    }

    private static boolean voidStep(Player p) {
        Location start = p.getLocation();
        Vector dir = start.getDirection().normalize();
        World w = p.getWorld();
        Location last = start.clone();
        Set<UUID> hit = new HashSet<>();
        for (double t = 0.5; t <= 8; t += 0.5) {
            Location l = start.clone().add(dir.clone().multiply(t));
            if (!l.getBlock().isPassable() || !l.clone().add(0, 1, 0).getBlock().isPassable()) break;
            last = l;
            w.spawnParticle(Particle.PORTAL, l.clone().add(0, 1, 0), 12, 0.3, 0.5, 0.3, 0.1);
            for (LivingEntity le : enemies(p, l, 1.6)) {
                if (hit.add(le.getUniqueId())) le.damage(7, p);
            }
        }
        last.setYaw(start.getYaw());
        last.setPitch(start.getPitch());
        p.teleport(last);
        p.setFallDistance(0);
        w.playSound(start, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
        w.playSound(last, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.8f);
        return true;
    }

    private static boolean blood(Player p) {
        LivingEntity target = nearest(p, 8);
        if (target == null) { fail(p, "Nenhum inimigo por perto. Alcance: 8 blocos."); return false; }
        target.damage(7, p);
        heal(p, 7);
        fx(p, PotionEffectType.STRENGTH, 100, 0);
        World w = p.getWorld();
        w.spawnParticle(Particle.DAMAGE_INDICATOR, target.getLocation().add(0, 1, 0), 15, 0.3, 0.5, 0.3, 0.1);
        w.spawnParticle(Particle.HEART, p.getLocation().add(0, 1.8, 0), 4, 0.3, 0.3, 0.3, 0);
        w.playSound(p.getLocation(), Sound.ENTITY_WITCH_DRINK, 1f, 0.7f);
        return true;
    }

    private static boolean frost(Player p) {
        Location c = p.getLocation();
        ring(c, 6, Particle.SNOWFLAKE, 70);
        ring(c, 3, Particle.SNOWFLAKE, 35);
        for (LivingEntity le : enemies(p, 6)) {
            le.damage(4, p);
            fx(le, PotionEffectType.SLOWNESS, 100, 2);
            le.setFreezeTicks(le.getMaxFreezeTicks());
        }
        p.getWorld().playSound(c, Sound.BLOCK_GLASS_BREAK, 1f, 0.5f);
        p.getWorld().playSound(c, Sound.ENTITY_PLAYER_HURT_FREEZE, 1f, 1f);
        return true;
    }

    private static boolean thunder(Player p) {
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        RayTraceResult rr = p.getWorld().rayTrace(eye, dir, 20, FluidCollisionMode.NEVER, true, 0.5,
                en -> !en.equals(p));
        Location target = rr != null && rr.getHitPosition() != null
                ? rr.getHitPosition().toLocation(p.getWorld())
                : eye.clone().add(dir.multiply(20));
        World w = p.getWorld();
        w.strikeLightningEffect(target);
        w.spawnParticle(Particle.ELECTRIC_SPARK, target, 40, 1.5, 0.5, 1.5, 0.1);
        for (LivingEntity le : enemies(p, target, 4)) {
            le.damage(9, p);
            le.setFireTicks(60);
        }
        return true;
    }

    private static boolean star(Player p) {
        Location c = p.getLocation();
        World w = c.getWorld();
        w.spawnParticle(Particle.END_ROD, c.clone().add(0, 2, 0), 60, 2.5, 1.2, 2.5, 0.05);
        ring(c, 7, Particle.END_ROD, 60);
        fx(p, PotionEffectType.SPEED, 120, 1);
        fx(p, PotionEffectType.ABSORPTION, 120, 1);
        for (LivingEntity le : enemies(p, 7)) {
            le.damage(5, p);
            fx(le, PotionEffectType.GLOWING, 100, 0);
        }
        w.playSound(c, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.2f, 1.2f);
        w.playSound(c, Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.5f);
        return true;
    }

    private static LivingEntity nearest(Player p, double radius) {
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (LivingEntity le : enemies(p, radius)) {
            double d = le.getLocation().distanceSquared(p.getLocation());
            if (d < bd) { bd = d; best = le; }
        }
        return best;
    }

    private static void fail(Player p, String msg) {
        p.sendActionBar(ReliquiasPlugin.c("§c" + msg));
    }

    // ---------- passivas (enquanto segura a relíquia) ----------
    private static void pas(Player p, PotionEffectType t, int amp, int ticks) {
        p.addPotionEffect(new PotionEffect(t, ticks, amp, true, false, true));
    }

    public static void passive(Relic r, Player p) {
        switch (r) {
            case DRAGON:  pas(p, PotionEffectType.FIRE_RESISTANCE, 0, 60); break;
            case ECLIPSE: pas(p, PotionEffectType.NIGHT_VISION, 0, 260); break;
            case PHOENIX: pas(p, PotionEffectType.REGENERATION, 0, 60); break;
            case TITAN:   pas(p, PotionEffectType.RESISTANCE, 0, 60); break;
            case STORM:
                pas(p, PotionEffectType.WATER_BREATHING, 0, 60);
                pas(p, PotionEffectType.DOLPHINS_GRACE, 0, 60);
                break;
            case VOID:
                pas(p, PotionEffectType.SPEED, 0, 60);
                pas(p, PotionEffectType.SLOW_FALLING, 0, 60);
                break;
            case BLOOD:   pas(p, PotionEffectType.STRENGTH, 0, 60); break;
            case FROST:
                pas(p, PotionEffectType.HASTE, 0, 60);
                p.setFreezeTicks(0);
                break;
            case THUNDER: pas(p, PotionEffectType.JUMP_BOOST, 1, 60); break;
            case STAR:    pas(p, PotionEffectType.HEALTH_BOOST, 0, 60); break;
            default: break;
        }
    }

    // ---------- ultimates (agachado + botão direito) ----------
    public static boolean ultimate(Relic r, Player p) {
        switch (r) {
            case DRAGON:  return uDragon(p);
            case ECLIPSE: return uEclipse(p);
            case PHOENIX: return uPhoenix(p);
            case TITAN:   return uTitan(p);
            case STORM:   return uStorm(p);
            case VOID:    return uVoid(p);
            case BLOOD:   return uBlood(p);
            case FROST:   return uFrost(p);
            case THUNDER: return uThunder(p);
            case STAR:    return uStar(p);
            default:      return false;
        }
    }

    private static boolean uDragon(Player p) {
        Location c = p.getLocation();
        ring(c, 8, Particle.FLAME, 90);
        ring(c, 5, Particle.FLAME, 60);
        c.getWorld().spawnParticle(Particle.FLAME, c.clone().add(0, 1, 0), 150, 4, 1, 4, 0.1);
        for (LivingEntity le : enemies(p, 8)) { le.setFireTicks(160); le.damage(10, p); }
        c.getWorld().playSound(c, Sound.ENTITY_ENDER_DRAGON_GROWL, 1f, 1f);
        return true;
    }

    private static boolean uEclipse(Player p) {
        Location c = p.getLocation();
        ring(c, 10, Particle.SMOKE, 90);
        ring(c, 6, Particle.SMOKE, 60);
        for (LivingEntity le : enemies(p, 10)) {
            fx(le, PotionEffectType.BLINDNESS, 160, 0);
            fx(le, PotionEffectType.DARKNESS, 200, 0);
            fx(le, PotionEffectType.WITHER, 100, 1);
            le.damage(6, p);
        }
        c.getWorld().playSound(c, Sound.ENTITY_WITHER_SPAWN, 0.8f, 0.5f);
        return true;
    }

    private static boolean uPhoenix(Player p) {
        Location c = p.getLocation();
        heal(p, 40);
        fx(p, PotionEffectType.ABSORPTION, 200, 2);
        fx(p, PotionEffectType.REGENERATION, 200, 1);
        ring(c, 6, Particle.FLAME, 80);
        c.getWorld().spawnParticle(Particle.HEART, c.clone().add(0, 1.8, 0), 12, 0.5, 0.4, 0.5, 0);
        for (LivingEntity le : enemies(p, 6)) {
            le.setFireTicks(120);
            le.damage(8, p);
            Vector kb = le.getLocation().toVector().subtract(c.toVector());
            if (kb.lengthSquared() > 0) le.setVelocity(kb.normalize().multiply(0.9).setY(0.5));
        }
        c.getWorld().playSound(c, Sound.ENTITY_BLAZE_SHOOT, 1f, 0.6f);
        c.getWorld().playSound(c, Sound.ITEM_TOTEM_USE, 0.8f, 1f);
        return true;
    }

    private static boolean uTitan(Player p) {
        Location c = p.getLocation();
        ring(c, 8, Particle.EXPLOSION, 24);
        ring(c, 4, Particle.CRIT, 50);
        fx(p, PotionEffectType.RESISTANCE, 120, 1);
        for (LivingEntity le : enemies(p, 8)) {
            le.damage(12, p);
            le.setVelocity(new Vector(0, 1.2, 0));
            fx(le, PotionEffectType.SLOWNESS, 80, 2);
            fx(le, PotionEffectType.WEAKNESS, 100, 0);
        }
        c.getWorld().playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.5f);
        c.getWorld().playSound(c, Sound.ENTITY_IRON_GOLEM_DEATH, 1f, 0.6f);
        return true;
    }

    private static boolean uStorm(Player p) {
        List<LivingEntity> list = enemies(p, 15);
        if (list.isEmpty()) { fail(p, "Nenhum inimigo por perto. Alcance: 15 blocos."); return false; }
        list.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(p.getLocation())));
        int n = Math.min(6, list.size());
        for (int i = 0; i < n; i++) {
            LivingEntity le = list.get(i);
            le.getWorld().strikeLightningEffect(le.getLocation());
            le.damage(10, p);
            fx(le, PotionEffectType.SLOWNESS, 60, 1);
        }
        return true;
    }

    private static boolean uVoid(Player p) {
        List<LivingEntity> list = enemies(p, 10);
        if (list.isEmpty()) { fail(p, "Nenhum inimigo por perto. Alcance: 10 blocos."); return false; }
        Location c = p.getLocation();
        for (LivingEntity le : list) {
            Vector pull = c.toVector().subtract(le.getLocation().toVector());
            if (pull.lengthSquared() > 0) le.setVelocity(pull.normalize().multiply(1.3).setY(0.4));
            le.damage(6, p);
            fx(le, PotionEffectType.SLOWNESS, 40, 1);
            le.getWorld().spawnParticle(Particle.PORTAL, le.getLocation().add(0, 1, 0), 30, 0.3, 0.5, 0.3, 0.3);
        }
        ring(c, 10, Particle.PORTAL, 80);
        c.getWorld().playSound(c, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.5f);
        return true;
    }

    private static boolean uBlood(Player p) {
        List<LivingEntity> list = enemies(p, 7);
        if (list.isEmpty()) { fail(p, "Nenhum inimigo por perto. Alcance: 7 blocos."); return false; }
        for (LivingEntity le : list) {
            le.damage(6, p);
            le.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, le.getLocation().add(0, 1, 0), 12, 0.3, 0.5, 0.3, 0.1);
        }
        heal(p, Math.min(12, 3.0 * list.size()));
        fx(p, PotionEffectType.STRENGTH, 160, 1);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WITCH_DRINK, 1f, 0.5f);
        return true;
    }

    private static boolean uFrost(Player p) {
        Location c = p.getLocation();
        ring(c, 9, Particle.SNOWFLAKE, 90);
        ring(c, 5, Particle.SNOWFLAKE, 50);
        fx(p, PotionEffectType.RESISTANCE, 100, 1);
        for (LivingEntity le : enemies(p, 9)) {
            le.damage(6, p);
            fx(le, PotionEffectType.SLOWNESS, 120, 4);
            fx(le, PotionEffectType.BLINDNESS, 40, 0);
            le.setFreezeTicks(le.getMaxFreezeTicks());
        }
        c.getWorld().playSound(c, Sound.BLOCK_GLASS_BREAK, 1f, 0.4f);
        c.getWorld().playSound(c, Sound.ENTITY_PLAYER_HURT_FREEZE, 1f, 0.8f);
        return true;
    }

    private static boolean uThunder(Player p) {
        Location eye = p.getEyeLocation();
        Vector dir = eye.getDirection().normalize();
        RayTraceResult rr = p.getWorld().rayTrace(eye, dir, 20, FluidCollisionMode.NEVER, true, 0.5,
                en -> !en.equals(p));
        Location target = rr != null && rr.getHitPosition() != null
                ? rr.getHitPosition().toLocation(p.getWorld())
                : eye.clone().add(dir.multiply(20));
        World w = p.getWorld();
        java.util.concurrent.ThreadLocalRandom rnd = java.util.concurrent.ThreadLocalRandom.current();
        for (int i = 0; i < 5; i++) {
            Location l = target.clone().add(rnd.nextDouble(-4, 4), 0, rnd.nextDouble(-4, 4));
            w.strikeLightningEffect(l);
            w.spawnParticle(Particle.ELECTRIC_SPARK, l, 30, 1, 0.5, 1, 0.1);
        }
        for (LivingEntity le : enemies(p, target, 5)) {
            le.damage(10, p);
            le.setFireTicks(80);
        }
        return true;
    }

    private static boolean uStar(Player p) {
        Location c = p.getLocation();
        World w = c.getWorld();
        ring(c, 10, Particle.END_ROD, 90);
        w.spawnParticle(Particle.END_ROD, c.clone().add(0, 2, 0), 120, 4, 1.5, 4, 0.08);
        w.spawnParticle(Particle.EXPLOSION, c.clone().add(0, 1, 0), 8, 3, 1, 3, 0);
        fx(p, PotionEffectType.SPEED, 200, 2);
        fx(p, PotionEffectType.REGENERATION, 200, 1);
        for (LivingEntity le : enemies(p, 10)) {
            le.damage(12, p);
            fx(le, PotionEffectType.GLOWING, 200, 0);
            Vector kb = le.getLocation().toVector().subtract(c.toVector());
            if (kb.lengthSquared() > 0) le.setVelocity(kb.normalize().multiply(1.1).setY(0.5));
        }
        w.playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.4f);
        w.playSound(c, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1.5f, 1.0f);
        return true;
    }

    // tipos de efeito aplicados pela passiva (para remover ao tirar a relíquia da mão)
    private static PotionEffectType[] passiveTypes(Relic r) {
        switch (r) {
            case DRAGON:  return new PotionEffectType[]{PotionEffectType.FIRE_RESISTANCE};
            case ECLIPSE: return new PotionEffectType[]{PotionEffectType.NIGHT_VISION};
            case PHOENIX: return new PotionEffectType[]{PotionEffectType.REGENERATION};
            case TITAN:   return new PotionEffectType[]{PotionEffectType.RESISTANCE};
            case STORM:   return new PotionEffectType[]{PotionEffectType.WATER_BREATHING, PotionEffectType.DOLPHINS_GRACE};
            case VOID:    return new PotionEffectType[]{PotionEffectType.SPEED, PotionEffectType.SLOW_FALLING};
            case BLOOD:   return new PotionEffectType[]{PotionEffectType.STRENGTH};
            case FROST:   return new PotionEffectType[]{PotionEffectType.HASTE};
            case THUNDER: return new PotionEffectType[]{PotionEffectType.JUMP_BOOST};
            case STAR:    return new PotionEffectType[]{PotionEffectType.HEALTH_BOOST};
            default:      return new PotionEffectType[0];
        }
    }

    public static void removePassive(Relic r, Player p) {
        for (PotionEffectType t : passiveTypes(r)) {
            PotionEffect pe = p.getPotionEffect(t);
            if (pe != null && pe.isAmbient() && !pe.hasParticles()) p.removePotionEffect(t);
        }
    }

    /** Partículas que giram em volta do jogador enquanto segura a relíquia. */
    public static void orbit(Relic r, Player p, long tick) {
        Particle part;
        switch (r) {
            case DRAGON:  part = Particle.FLAME; break;
            case ECLIPSE: part = Particle.SMOKE; break;
            case PHOENIX: part = Particle.LAVA; break;
            case TITAN:   part = Particle.ASH; break;
            case STORM:   part = Particle.NAUTILUS; break;
            case VOID:    part = Particle.PORTAL; break;
            case BLOOD:   part = Particle.CRIMSON_SPORE; break;
            case FROST:   part = Particle.SNOWFLAKE; break;
            case THUNDER: part = Particle.ELECTRIC_SPARK; break;
            case STAR:    part = Particle.END_ROD; break;
            default: return;
        }
        Location base = p.getLocation();
        World w = base.getWorld();
        for (int k = 0; k < 3; k++) {
            double ang = tick * 0.3 + k * (2 * Math.PI / 3);
            double y = 0.25 + k * 0.7 + 0.15 * Math.sin(tick * 0.2 + k);
            w.spawnParticle(part, base.getX() + Math.cos(ang) * 1.0, base.getY() + y,
                    base.getZ() + Math.sin(ang) * 1.0, 1, 0, 0, 0, 0);
        }
    }
}
