# Relíquias Lendárias 2.0
Build: suba esta pasta para um repositório no GitHub; a aba Actions gera o .jar (artifact "ReliquiasLendarias").
Ou localmente: `mvn package` (Java 21+).
